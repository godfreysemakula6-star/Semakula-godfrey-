classdef SimpleDifferentialSolver < SimpleSolver
    % SIMPLEDIFFERENTIALSOLVER Solves differential equations
    
    methods
        function results = solve(obj, equation, initial, step, steps)
            % Simple ODE solver using Euler method
            
            fprintf('Solving Differential Equation\n');
            
            x0 = initial(1);
            y0 = initial(2);
            
            results = zeros(steps + 1, 2);
            results(1, :) = [x0, y0];
            
            for i = 1:steps
                x = results(i, 1);
                y = results(i, 2);
                
                % Euler method: y_new = y_old + step * f(x, y)
                y_new = y + step * equation(x, y);
                x_new = x + step;
                
                results(i + 1, :) = [x_new, y_new];
                
                % Simple progress display
                if mod(i, 10) == 0
                    fprintf('Step %d: x=%.2f, y=%.4f\n', i, x_new, y_new);
                end
            end
            
            fprintf('Final: x=%.2f, y=%.4f\n', results(end, 1), results(end, 2));
        end
    end
end