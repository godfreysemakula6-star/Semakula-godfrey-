function simple_numerical_gui()
    % SIMPLE_NUMERICAL_GUI Simplified GUI for Numerical Solvers
    %
    % Basic interface for differential and integral solvers.
    % Uses a single figure with radio buttons to switch modes.

    % Create main figure
    fig = uifigure('Name', 'Simple Numerical GUI', ...
                   'Position', [100, 100, 600, 500]);

    % Mode selector
    uilabel(fig, 'Text', 'Mode:', 'Position', [20, 460, 50, 22]);
    mode_group = uibuttongroup(fig, 'Position', [80, 450, 200, 40]);
    de_radio = uiradiobutton(mode_group, 'Text', 'Differential Eq', ...
                             'Position', [0, 0, 120, 22]);
    int_radio = uiradiobutton(mode_group, 'Text', 'Integral', ...
                              'Position', [130, 0, 70, 22]);

    % Shared inputs (adjusted for both modes)
    uilabel(fig, 'Text', 'Function (e.g., -2*x*y or x.^2.*sin(x)):', ...
            'Position', [20, 420, 200, 22]);
    func_edit = uieditfield(fig, 'text', 'Position', [230, 420, 200, 22], ...
                            'Value', '-2*x*y');  % Default for DE

    % DE specific inputs
    uilabel(fig, 'Text', 'x0:', 'Position', [20, 380, 30, 22]);
    x0_edit = uieditfield(fig, 'numeric', 'Position', [60, 380, 60, 22], ...
                          'Value', 0, 'Visible', 'on');
    uilabel(fig, 'Text', 'y0:', 'Position', [140, 380, 30, 22]);
    y0_edit = uieditfield(fig, 'numeric', 'Position', [180, 380, 60, 22], ...
                          'Value', 1, 'Visible', 'on');
    uilabel(fig, 'Text', 'h:', 'Position', [260, 380, 20, 22]);
    h_edit = uieditfield(fig, 'numeric', 'Position', [290, 380, 60, 22], ...
                         'Value', 0.1, 'Visible', 'on');
    uilabel(fig, 'Text', 'Steps:', 'Position', [370, 380, 50, 22]);
    steps_edit = uieditfield(fig, 'numeric', 'Position', [430, 380, 60, 22], ...
                             'Value', 50, 'Visible', 'on');

    % Integral specific inputs
    a_label = uilabel(fig, 'Text', 'a:', 'Position', [20, 380, 20, 22], ...
            'Visible', 'off');
    a_edit = uieditfield(fig, 'numeric', 'Position', [50, 380, 60, 22], ...
                         'Value', 0, 'Visible', 'off');
    b_label = uilabel(fig, 'Text', 'b:', 'Position', [130, 380, 20, 22], ...
            'Visible', 'off');
    b_edit = uieditfield(fig, 'numeric', 'Position', [160, 380, 60, 22], ...
                         'Value', pi, 'Visible', 'off');

    % Solve button
    solve_btn = uibutton(fig, 'Text', 'Solve', 'Position', [20, 340, 80, 30], ...
                         'ButtonPushedFcn', @(btn,event) solve_callback());

    % Axes for plot
    ax = uiaxes(fig, 'Position', [20, 100, 560, 220]);

    % Output text area
    output_text = uitextarea(fig, 'Position', [20, 20, 560, 70], ...
                             'Value', {'Select mode and input parameters...'});

    % Callback to toggle visibility and set defaults
    mode_group.SelectionChangedFcn = @(src,evt) toggle_inputs(evt.NewValue.Text);

    function toggle_inputs(mode)
        if strcmp(mode, 'Differential Eq')
            set(x0_edit, 'Visible', 'on');
            set(y0_edit, 'Visible', 'on');
            set(h_edit, 'Visible', 'on');
            set(steps_edit, 'Visible', 'on');
            set(a_edit, 'Visible', 'off');
            set(b_edit, 'Visible', 'off');
            set(a_label, 'Visible', 'off');
            set(b_label, 'Visible', 'off');
            % DE default
            set(func_edit, 'Value', '-2*x*y');
        else
            set(x0_edit, 'Visible', 'off');
            set(y0_edit, 'Visible', 'off');
            set(h_edit, 'Visible', 'off');
            set(steps_edit, 'Visible', 'off');
            set(a_edit, 'Visible', 'on');
            set(b_edit, 'Visible', 'on');
            set(a_label, 'Visible', 'on');
            set(b_label, 'Visible', 'on');
            % Integral default (no 'y')
            set(func_edit, 'Value', 'x.^2 .* sin(x)');
        end
    end

    % Solve callback
    function solve_callback()
        try
            func_str = get(func_edit, 'Value');
            if strcmp(mode_group.SelectedObject.Text, 'Differential Eq')
                x0 = get(x0_edit, 'Value');
                y0 = get(y0_edit, 'Value');
                h = get(h_edit, 'Value');
                steps = get(steps_edit, 'Value');
                eq_func = str2func(['@(x,y) ' func_str]);
                solver = SimpleDifferentialSolver();
                results = solver.solve(eq_func, [x0, y0], h, steps);
                cla(ax);
                plot(ax, results(:,1), results(:,2), 'b-', 'LineWidth', 2);
                xlabel(ax, 'x'); ylabel(ax, 'y');
                title(ax, 'Solution Curve'); grid(ax, 'on');
                set(output_text, 'Value', {sprintf('Solved y'' = %s from x=%g, y=%g (h=%g, %d steps).', ...
                    func_str, x0, y0, h, steps); ...
                    sprintf('Final: x=%.4f, y=%.6f', results(end,1), results(end,2))});
            else
                a = get(a_edit, 'Value');
                b = get(b_edit, 'Value');
                int_func = str2func(['@(x) ' func_str]);
                solver = SimpleIntegralSolver();
                result = solver.solve(int_func, a, b);
                cla(ax);
                x_plot = linspace(a, b, 500);
                y_plot = int_func(x_plot);
                plot(ax, x_plot, y_plot, 'r-', 'LineWidth', 1);
                hold(ax, 'on');
                fill(ax, [x_plot, fliplr(x_plot)], [y_plot, zeros(size(y_plot))], 'g', 'FaceAlpha', 0.3);
                xlabel(ax, 'x'); ylabel(ax, 'f(x)');
                title(ax, sprintf('Integrand from %g to %g', a, b)); grid(ax, 'on');
                hold(ax, 'off');
                set(output_text, 'Value', {sprintf('Integrated %s from %g to %g (Simpson''s rule).', ...
                    func_str, a, b); sprintf('Result: %.6f', result)});
            end
        catch ME
            set(output_text, 'Value', {['Error: ' ME.message]});
        end
    end

end