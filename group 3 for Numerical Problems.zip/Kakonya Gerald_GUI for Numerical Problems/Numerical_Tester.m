% SIMPLE NUMERICAL METHODS DEMO

function simple_numerical_demo()
    fprintf('=== SIMPLE NUMERICAL METHODS ===\n\n');
    
    % Create solvers
    diff_solver = SimpleDifferentialSolver();
    int_solver = SimpleIntegralSolver();
    
    % EXAMPLE 1: Solve differential equation y' = -2x * y
    fprintf('1. DIFFERENTIAL EQUATION:\n');
    equation = @(x, y) -2 * x * y;  % y' = -2x*y
    initial = [0, 1];  % y(0) = 1
    
    solution = diff_solver.solve(equation, initial, 0.1, 50);
    
    % EXAMPLE 2: Solve integral ∫(x² * sin(x)) dx from 0 to π
    fprintf('\n2. INTEGRAL:\n');
    func = @(x) x.^2 .* sin(x);
    a = 0;
    b = pi;
    
    integral_result = int_solver.solve(func, a, b);
    
    % EXAMPLE 3: Another integral
    fprintf('\n3. ANOTHER INTEGRAL:\n');
    func2 = @(x) exp(-x.^2);  % Gaussian function
    integral2 = int_solver.solve(func2, 0, 2);
    
    fprintf('\n=== ALL DONE ===\n');
end

% Run the demo
simple_numerical_demo()