classdef SimpleIntegralSolver < SimpleSolver
    % SIMPLEINTEGRALSOLVER Solves integral problems
    
    methods
        function result = solve(obj, function_handle, a, b)
            % Simple integral solver using Simpson's rule
            
            fprintf('Solving Integral from %.1f to %.1f\n', a, b);
            
            n = 100; % Number of segments
            h = (b - a) / n;
            
            % Simpson's rule
            x = a:h:b;
            y = function_handle(x);
            
            result = (h/3) * (y(1) + y(end) + ...
                      4 * sum(y(2:2:end-1)) + ...
                      2 * sum(y(3:2:end-2)));
            
            fprintf('Integral result: %.6f\n', result);
        end
    end
end