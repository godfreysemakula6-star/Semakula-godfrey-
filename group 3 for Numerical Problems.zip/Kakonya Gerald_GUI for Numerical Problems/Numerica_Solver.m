classdef (Abstract) SimpleSolver
    % SIMPLESOLVER Abstract base class for numerical solvers
    
    properties
        tolerance = 1e-6
        max_iterations = 100
    end
    
    methods (Abstract)
        result = solve(obj, problem)
    end
    
    methods
        function obj = SimpleSolver()
            % Simple constructor
        end
        
        function check(obj, value, iter)
            % Basic convergence check
            if abs(value) < obj.tolerance
                fprintf('Converged in %d iterations\n', iter);
            elseif iter >= obj.max_iterations
                error('Max iterations reached');
            end
        end
    end
end