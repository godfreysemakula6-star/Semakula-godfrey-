function stormwater_analysis_gui
    % Create the main figure
    fig = uifigure('Position', [100, 100, 1200, 800], 'Name', 'Stormwater Drainage Analysis');
    
    % Create tabs for different sections
    tabGroup = uitabgroup(fig, 'Position', [20, 50, 1160, 700]);
   
    % Rainfall Frequency Analysis Tab
    rainfallTab = uitab(tabGroup, 'Title', 'Rainfall Analysis');
    % Input for rainfall data
    uilabel(rainfallTab, 'Position', [20, 650, 200, 22], 'Text', 'Annual Max Rainfall (mm, space-separated):');
    editRainData = uieditfield(rainfallTab, 'text', 'Position', [20, 620, 300, 22], ...
                               'Value', mat2str([150, 162, 145, 178, 155, 168, 140, 182, 160, 172, ...
                                                 148, 165, 152, 175, 158, 170, 142, 180, 155, 169, ...
                                                 146, 163, 150, 177, 154, 167, 139, 181, 159, 171]));
    % Input for return periods
    uilabel(rainfallTab, 'Position', [20, 580, 200, 22], 'Text', 'Return Periods (years, space-separated):');
    editT = uieditfield(rainfallTab, 'text', 'Position', [20, 550, 300, 22], 'Value', '10 25 50');
    uibutton(rainfallTab, 'Text', 'Run Rainfall Analysis', 'Position', [20, 510, 150, 30], ...
             'ButtonPushedFcn', @(btn, event) runRainfallAnalysis(rainfallTab, editRainData, editT));
    % Axes for plots
    axesRainHist = uiaxes(rainfallTab, 'Position', [350, 300, 800, 200]);
    axesRainDesign = uiaxes(rainfallTab, 'Position', [350, 50, 800, 200]);
    title(axesRainHist, 'Histogram & Gumbel Fit');
    title(axesRainDesign, 'Design Storms');
   
    % Watershed Parameters Tab
    watershedTab = uitab(tabGroup, 'Title', 'Watershed Parameters');
    uilabel(watershedTab, 'Position', [20, 650, 200, 22], 'Text', 'Number of Sub-Watersheds:');
    editNumWS = uieditfield(watershedTab, 'numeric', 'Position', [20, 620, 100, 22], 'Value', 82);
    uibutton(watershedTab, 'Text', 'Run Watershed Parameters', 'Position', [20, 580, 150, 30], ...
             'ButtonPushedFcn', @(btn, event) runWatershedParameters(watershedTab, editNumWS));
    axesWS = uiaxes(watershedTab, 'Position', [200, 50, 900, 500]);
    title(axesWS, 'Watershed Parameters Distributions');
   
    % Runoff Simulation Tab
    runoffTab = uitab(tabGroup, 'Title', 'Runoff Simulation');
    uilabel(runoffTab, 'Position', [20, 650, 200, 22], 'Text', 'Sample Area (km²):');
    editArea = uieditfield(runoffTab, 'numeric', 'Position', [20, 620, 100, 22], 'Value', 2.0);
    uilabel(runoffTab, 'Position', [20, 580, 200, 22], 'Text', 'Sample Curve Number (CN):');
    editCN = uieditfield(runoffTab, 'numeric', 'Position', [20, 550, 100, 22], 'Value', 80);
    uilabel(runoffTab, 'Position', [20, 510, 200, 22], 'Text', 'Design Rain (mm, 10-yr):');
    editP = uieditfield(runoffTab, 'numeric', 'Position', [20, 480, 100, 22], 'Value', 181);
    uibutton(runoffTab, 'Text', 'Run Runoff Simulation', 'Position', [20, 440, 150, 30], ...
             'ButtonPushedFcn', @(btn, event) runRunoffSimulation(runoffTab, editArea, editCN, editP));
    axesRunoff = uiaxes(runoffTab, 'Position', [200, 50, 900, 350]);
    title(axesRunoff, 'Runoff Hydrograph');
   
    % Hydraulic Competence Tab
    competenceTab = uitab(tabGroup, 'Title', 'Hydraulic Competence');
    uilabel(competenceTab, 'Position', [20, 650, 200, 22], 'Text', 'Random Seed for Simulation:');
    editSeed = uieditfield(competenceTab, 'numeric', 'Position', [20, 620, 100, 22], 'Value', 42);
    uibutton(competenceTab, 'Text', 'Assess Hydraulic Competence', 'Position', [20, 580, 150, 30], ...
             'ButtonPushedFcn', @(btn, event) assessHydraulicCompetence(competenceTab, editSeed));
    axesCompDrain = uiaxes(competenceTab, 'Position', [200, 350, 500, 200]);
    title(axesCompDrain, 'Drains Competence (10 & 25-yr)');
    axesCompCulv = uiaxes(competenceTab, 'Position', [200, 100, 500, 200]);
    title(axesCompCulv, 'Culverts Competence (25 & 50-yr)');
   
    % Recommendations Tab
    recommendationsTab = uitab(tabGroup, 'Title', 'Recommendations');
    uibutton(recommendationsTab, 'Text', 'Show Recommendations', 'Position', [200, 150, 200, 50], ...
             'ButtonPushedFcn', @(btn, event) showRecommendations(recommendationsTab));
    axesRec = uiaxes(recommendationsTab, 'Position', [20, 50, 500, 400]);
    title(axesRec, 'Recommended Interventions');
    
    % Output text area at bottom
    txtOutput = uitextarea(fig, 'Position', [20, 10, 1160, 30], ...
                           'Value', {'Output: Ready to analyze...'}, 'Editable', 'off');
    
    % Callback functions for each section
    function runRainfallAnalysis(tab, editRain, editT)
        % Parse inputs
        rainStr = editRain.Value;
        annual_max_rain = str2num(rainStr); %#ok<ST2NM>
        TStr = editT.Value;
        T = str2num(TStr); %#ok<ST2NM>
        
        pd = fitdist(annual_max_rain', 'ExtremeValue');
        loc = pd.mu; scale = pd.sigma;
        design_rain = loc - scale * log(-log(1 - 1./T));
       
        % Display results
        txtOutput.Value = {'Fitted Gumbel parameters: loc = ', num2str(loc), ', scale = ', num2str(scale)};
        txtOutput.Value{end+1} = 'Design storms (mm):';
        for i = 1:length(T)
            txtOutput.Value{end+1} = [' ', num2str(T(i)), '-year: ', num2str(design_rain(i))];
        end
       
        % Plot histogram
        cla(axesRainHist);
        histogram(axesRainHist, annual_max_rain, 10, 'Normalization', 'pdf', 'FaceAlpha', 0.6, 'DisplayName', 'Empirical');
        hold(axesRainHist, 'on');
        x = linspace(min(annual_max_rain)-10, max(annual_max_rain)+10, 100);
        plot(axesRainHist, x, pdf(pd, x), 'r-', 'LineWidth', 2, 'DisplayName', 'Gumbel Fit');
        xlabel(axesRainHist, 'Annual Max Rainfall (mm)');
        ylabel(axesRainHist, 'Density');
        title(axesRainHist, 'Rainfall Frequency Analysis: Gumbel Distribution Fit');
        legend(axesRainHist, 'Location', 'best');
        grid(axesRainHist, 'on');
        
        % Plot design storms
        cla(axesRainDesign);
        plot(axesRainDesign, T, design_rain, 'bo-', 'LineWidth', 2, 'MarkerSize', 8);
        xlabel(axesRainDesign, 'Return Period (years)');
        ylabel(axesRainDesign, 'Design Rainfall (mm)');
        title(axesRainDesign, 'Design Storms for Kasese Municipality');
        grid(axesRainDesign, 'on');
    end
    
    function runWatershedParameters(tab, editNum)
        num_watersheds = editNum.Value;
        rng(42); % For reproducibility
        areas = 0.5 + 4.5 * rand(num_watersheds, 1);
        slopes = 0.5 + 2.5 * rand(num_watersheds, 1);
        CN = 70 + 20 * rand(num_watersheds, 1);
        Tc = 0.0135 * (areas.^0.385) .* (slopes.^(-0.3));
        
        % Display sample
        txtOutput.Value = {'Sample Watershed Params (first 5):'};
        for i = 1:min(5, num_watersheds)
            txtOutput.Value{end+1} = [' WS', num2str(i), ': Area = ', num2str(areas(i)), ' km², Slope = ', ...
                                      num2str(slopes(i)), '%, CN = ', num2str(CN(i)), ', Tc = ', num2str(Tc(i)), ' hr'];
        end
        
        % Plot in axes
        cla(axesWS);
        subplot(2,2,1, 'Parent', axesWS);
        histogram(areas, 15, 'FaceAlpha', 0.7);
        title('Watershed Areas Distribution');
        xlabel('Area (km²)');
       
        subplot(2,2,2, 'Parent', axesWS);
        scatter(areas, Tc, 'filled');
        title('Area vs Time of Concentration');
        xlabel('Area (km²)'); ylabel('Tc (hr)');
       
        subplot(2,2,3, 'Parent', axesWS);
        histogram(CN, 10, 'FaceAlpha', 0.7);
        title('Curve Number Distribution');
        xlabel('CN');
       
        subplot(2,2,4, 'Parent', axesWS);
        scatter(slopes, CN, 'filled');
        title('Slope vs Curve Number');
        xlabel('Slope (%)'); ylabel('CN');
       
        sgtitle(axesWS, 'Watershed Parameters from DEM Delineation (82 Sub-Watersheds)');
    end
    
    function runRunoffSimulation(tab, editArea, editCN, editP)
        sample_area = editArea.Value;
        sample_CN = editCN.Value;
        sample_P_mm = editP.Value;
        P_in = sample_P_mm / 25.4;
        S_in = 1000 / sample_CN - 10;
        Ia_in = 0.2 * S_in;
        Q_in = max(0, (P_in - Ia_in)^2 / (P_in + S_in - Ia_in));
        Q_m3s = Q_in * 25.4 / 1000 * sample_area * 1e6 / 3600;
        
        txtOutput.Value = {['Sample Runoff for 10-yr storm: P = ', num2str(sample_P_mm), ' mm, Q_peak ~', num2str(Q_m3s), ' m³/s']};
        
        % Hydrograph
        sample_Tc = 0.5; % hr
        tp = sample_Tc;
        tb = 2.67 * sample_Tc;
        t = linspace(0, tb, 100);
        Q_h = zeros(size(t));
        mask_rise = t <= tp;
        Q_h(mask_rise) = (t(mask_rise) / tp) * Q_m3s;
        mask_fall = t > tp;
        Q_h(mask_fall) = Q_m3s * (1 - (t(mask_fall) - tp) / (tb - tp));
        
        % Plot in axes
        cla(axesRunoff);
        plot(axesRunoff, t, Q_h, 'b-', 'LineWidth', 2);
        xlabel(axesRunoff, 'Time (hours)');
        ylabel(axesRunoff, 'Discharge (m³/s)');
        title(axesRunoff, sprintf('Simulated Runoff Hydrograph for 10-yr Design Storm\n(Area=%.1f km², CN=%.0f)', sample_area, sample_CN));
        grid(axesRunoff, 'on');
    end
    
    function assessHydraulicCompetence(tab, editSeed)
        rng(editSeed.Value);
        sections = {'Kamplinkwizi_1', 'Kasese_Primary_1', 'Kamplinkwizi_2', 'Kasese_Primary_2', ...
                    'Culvert_A', 'Drain_B', 'Culvert_C', 'Kasese_Primary_3', 'Kamplinkwizi_3', 'Culvert_D'};
        Q_sim_10yr = 0.5 + 2.5 * rand(10, 1);
        Q_sim_25yr = Q_sim_10yr * 1.2;
        Q_cap_drains = [2.5, 1.0, 3.0, 0.8, 2.0, 1.5, 2.8, 0.9, 2.2, 1.8];
        Q_cap_culverts = Q_cap_drains * 1.5;
        competent_10yr_drains = Q_sim_10yr(1:4) < Q_cap_drains(1:4);
        competent_25yr_drains = Q_sim_25yr(1:4) < Q_cap_drains(1:4);
        competent_25yr_culv = Q_sim_25yr(5:10) < Q_cap_culverts(5:10);
        competent_50yr_culv = Q_sim_25yr(5:10) * 1.2 < Q_cap_culverts(5:10);
        
        txtOutput.Value = {'Hydraulic Competence (Sample Sections):'};
        for i = 1:10
            if i <= 4 % Drains
                txtOutput.Value{end+1} = [sections{i}, ' (Drain): 10yr ', ifelse(competent_10yr_drains(i), 'Competent', 'Incompetent'), ...
                                          ', 25yr ', ifelse(competent_25yr_drains(i), 'Competent', 'Incompetent')];
            else % Culverts
                txtOutput.Value{end+1} = [sections{i}, ' (Culvert): 25yr ', ifelse(competent_25yr_culv(i-4), 'Competent', 'Incompetent'), ...
                                          ', 50yr ', ifelse(competent_50yr_culv(i-4), 'Competent', 'Incompetent')];
            end
        end
        
        % Plot Competence for Drains
        x = 1:4;
        width = 0.35;
        cla(axesCompDrain);
        bar(axesCompDrain, x - width/2, double(competent_10yr_drains), width, 'FaceColor', [0.2 0.6 1]);
        hold(axesCompDrain, 'on');
        bar(axesCompDrain, x + width/2, double(competent_25yr_drains), width, 'FaceColor', [1 0.4 0.2]);
        xlabel(axesCompDrain, 'Drain Sections');
        ylabel(axesCompDrain, 'Competence (1=Yes, 0=No)');
        title(axesCompDrain, 'Hydraulic Competence Assessment for Drains (10 & 25-yr)');
        set(axesCompDrain, 'XTick', x, 'XTickLabel', sections(1:4), 'XTickLabelRotation', 45);
        legend(axesCompDrain, {'10-yr Competent', '25-yr Competent'}, 'Location', 'best');
        grid(axesCompDrain, 'on');
        
        % Plot Competence for Culverts
        x_c = 1:6;
        cla(axesCompCulv);
        bar(axesCompCulv, x_c - width/2, double(competent_25yr_culv), width, 'FaceColor', [0.2 0.6 1]);
        hold(axesCompCulv, 'on');
        bar(axesCompCulv, x_c + width/2, double(competent_50yr_culv), width, 'FaceColor', [1 0.4 0.2]);
        xlabel(axesCompCulv, 'Culvert Sections');
        ylabel(axesCompCulv, 'Competence (1=Yes, 0=No)');
        title(axesCompCulv, 'Hydraulic Competence Assessment for Culverts (25 & 50-yr)');
        set(axesCompCulv, 'XTick', x_c, 'XTickLabel', sections(5:10), 'XTickLabelRotation', 45);
        legend(axesCompCulv, {'25-yr Competent', '50-yr Competent'}, 'Location', 'best');
        grid(axesCompCulv, 'on');
    end
    
    function showRecommendations(tab)
        recommendations = {'Sustainable Design Options', 'Silt Traps', 'Better Solid Waste Mgmt', 'Regular Maintenance'};
        percent = [25, 25, 25, 25]; % Equal weights
        
        txtOutput.Value = {'Recommended Interventions: Integration of sustainable options, silt traps, waste mgmt, maintenance.'};
        
        cla(axesRec);
        pie(axesRec, percent, recommendations);
        title(axesRec, 'Recommended Interventions for Drainage Improvement');
    end
    
    % Helper function for conditional string (nested)
    function str = ifelse(cond, true_str, false_str)
        if cond
            str = true_str;
        else
            str = false_str;
        end
    end
end