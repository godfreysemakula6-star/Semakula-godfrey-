%% MATLAB Code Implementation for Stormwater Drainage Analysis in Kasese Municipality
% This script simulates key components of the abstract:
% 1. Rainfall frequency analysis using Gumbel distribution (fitted to sample data).
% 2. Simulated watershed parameters (82 sub-watersheds: area, slope, CN, Tc).
% 3. Runoff simulation using SCS-CN method (proxy for PCSWMM) for a sample sub-watershed.
% 4. Hydraulic competence assessment for sample drain/culvert sections.
% 5. Recommendations visualization.
%
% Requires: Statistics and Machine Learning Toolbox (for fitdist).
% Sample values: 30 years of annual max rainfall (140-182 mm, tropical avg);
% Design rains ~181 mm (10-yr), ~192 mm (25-yr), ~200 mm (50-yr);
% Peak Q ~67.9 m³/s for 2 km² basin under 10-yr storm.
% Plots saved as PNG files for visualization.

clear; clc; close all;

%% 1. Rainfall Frequency Analysis using Gumbel Distribution
% Sample annual maximum rainfall data (mm) for 30 years
annual_max_rain = [150, 162, 145, 178, 155, 168, 140, 182, 160, 172, ...
                   148, 165, 152, 175, 158, 170, 142, 180, 155, 169, ...
                   146, 163, 150, 177, 154, 167, 139, 181, 159, 171];

% Fit Gumbel distribution (Type I Extreme Value for maxima)
pd = fitdist(annual_max_rain', 'ExtremeValue');
loc = pd.mu; scale = pd.sigma;
fprintf('Fitted Gumbel parameters: loc=%.2f, scale=%.2f\n', loc, scale);

% Return periods
T = [10, 25, 50];  % years
% Gumbel quantile: x_T = loc - scale * log(-log(1 - 1/T))
design_rain = loc - scale * log(-log(1 - 1./T));
fprintf('Design storms (mm):\n');
for i = 1:length(T)
    fprintf('  %d-year: %.2f\n', T(i), design_rain(i));
end

% Plot: Empirical vs Fitted Gumbel
x = linspace(min(annual_max_rain)-10, max(annual_max_rain)+10, 100);
gumbel_pdf = pdf(pd, x);
figure('Position', [100, 100, 800, 500]);
histogram(annual_max_rain, 10, 'Normalization', 'pdf', 'FaceAlpha', 0.6, 'DisplayName', 'Empirical');
hold on;
plot(x, gumbel_pdf, 'r-', 'LineWidth', 2, 'DisplayName', 'Gumbel Fit');
xlabel('Annual Max Rainfall (mm)');
ylabel('Density');
title('Rainfall Frequency Analysis: Gumbel Distribution Fit');
legend; grid on;
saveas(gcf, 'rainfall_fit.png');

% Plot: Design Storms
figure('Position', [100, 100, 600, 400]);
plot(T, design_rain, 'bo-', 'LineWidth', 2, 'MarkerSize', 8);
xlabel('Return Period (years)');
ylabel('Design Rainfall (mm)');
title('Design Storms for Kasese Municipality');
grid on;
saveas(gcf, 'design_storms.png');

%% 2. Simulated Watershed Parameters (from DEM Delineation)
% 82 sub-watersheds; random params for demo
num_watersheds = 82;
rng(42);  % For reproducibility
areas = 0.5 + 4.5 * rand(num_watersheds, 1);  % km² (0.5-5.0)
slopes = 0.5 + 2.5 * rand(num_watersheds, 1);  % %
CN = 70 + 20 * rand(num_watersheds, 1);  % Curve Number (70-90, urbanizing)
% Kirpich Tc (hr): Tc = 0.0135 * L^{0.77} * (S^{-0.385}), approx with area proxy L~sqrt(area)
Tc = 0.0135 * (areas.^0.385) .* (slopes.^(-0.3));

fprintf('\nSample Watershed Params (first 5):\n');
for i = 1:5
    fprintf('  WS%d: Area=%.2f km², Slope=%.1f%%, CN=%.1f, Tc=%.2f hr\n', ...
            i, areas(i), slopes(i), CN(i), Tc(i));
end

% Plot: Watershed Characteristics
figure('Position', [100, 100, 1000, 800]);
subplot(2,2,1);
histogram(areas, 15, 'FaceAlpha', 0.7);
title('Watershed Areas Distribution');
xlabel('Area (km²)');

subplot(2,2,2);
scatter(areas, Tc, 'filled');
title('Area vs Time of Concentration');
xlabel('Area (km²)'); ylabel('Tc (hr)');

subplot(2,2,3);
histogram(CN, 10, 'FaceAlpha', 0.7);
title('Curve Number Distribution');
xlabel('CN');

subplot(2,2,4);
scatter(slopes, CN, 'filled');
title('Slope vs Curve Number');
xlabel('Slope (%)'); ylabel('CN');

sgtitle('Watershed Parameters from DEM Delineation (82 Sub-Watersheds)');
saveas(gcf, 'watershed_params.png');

%% 3. Runoff Simulation using SCS-CN Method (Proxy for PCSWMM)
% Sample sub-watershed: Area=2 km², CN=80, P=10-yr design rain
sample_area = 2.0;  % km²
sample_CN = 80;
sample_P_mm = design_rain(1);  % mm

% SCS-CN in inches
P_in = sample_P_mm / 25.4;
S_in = 1000 / sample_CN - 10;
Ia_in = 0.2 * S_in;
Q_in = max(0, (P_in - Ia_in)^2 / (P_in + S_in - Ia_in));  % inches
Q_m3s = Q_in * 25.4 / 1000 * sample_area * 1e6 / 3600;  % m³/s (peak approx)

fprintf('\nSample Runoff for 10-yr storm:\n');
fprintf('  P=%.0f mm, Q_peak ~%.1f m³/s (for %.1f km²)\n', sample_P_mm, Q_m3s, sample_area);

% Simple Triangular Hydrograph: base=2.67 Tc, peak at 0.666 Tc
sample_Tc = 0.5;  % hr
tp = sample_Tc;  % time to peak
tb = 2.67 * sample_Tc;  % base time
t = linspace(0, tb, 100);  % hours
Q_h = zeros(size(t));
mask_rise = t <= tp;
Q_h(mask_rise) = (t(mask_rise) / tp) * Q_m3s;
mask_fall = t > tp;
Q_h(mask_fall) = Q_m3s * (1 - (t(mask_fall) - tp) / (tb - tp));

% Plot Hydrograph
figure('Position', [100, 100, 800, 500]);
plot(t, Q_h, 'b-', 'LineWidth', 2);
xlabel('Time (hours)');
ylabel('Discharge (m³/s)');
title(sprintf('Simulated Runoff Hydrograph for 10-yr Design Storm\n(Area=%.1f km², CN=%.0f)', sample_area, sample_CN));
grid on;
saveas(gcf, 'runoff_hydrograph.png');

%% 4. Hydraulic Competence Assessment (Simplified)
% Sample 10 sections: Q_sim for 10/25-yr, capacities
sections = {'Kamplinkwizi_1', 'Kasese_Primary_1', 'Kamplinkwizi_2', 'Kasese_Primary_2', ...
            'Culvert_A', 'Drain_B', 'Culvert_C', 'Kasese_Primary_3', 'Kamplinkwizi_3', 'Culvert_D'};
Q_sim_10yr = 0.5 + 2.5 * rand(10, 1);  % m³/s
Q_sim_25yr = Q_sim_10yr * 1.2;
Q_cap_drains = [2.5, 1.0, 3.0, 0.8, 2.0, 1.5, 2.8, 0.9, 2.2, 1.8];  % m³/s
Q_cap_culverts = Q_cap_drains * 1.5;  % Larger for culverts

% Competence checks
competent_10yr_drains = Q_sim_10yr(1:4) < Q_cap_drains(1:4);
competent_25yr_drains = Q_sim_25yr(1:4) < Q_cap_drains(1:4);
competent_25yr_culv = Q_sim_25yr(5:10) < Q_cap_culverts(5:10);
competent_50yr_culv = Q_sim_25yr(5:10) * 1.2 < Q_cap_culverts(5:10);

fprintf('\nHydraulic Competence (Sample Sections):\n');
for i = 1:10
    if i <= 4  % Drains
        fprintf('  %s (Drain): 10yr %s, 25yr %s\n', sections{i}, ...
                ifelse(competent_10yr_drains(i), 'Competent', 'Incompetent'), ...
                ifelse(competent_25yr_drains(i), 'Competent', 'Incompetent'));
    else  % Culverts
        fprintf('  %s (Culvert): 25yr %s, 50yr %s\n', sections{i}, ...
                ifelse(competent_25yr_culv(i-4), 'Competent', 'Incompetent'), ...
                ifelse(competent_50yr_culv(i-4), 'Competent', 'Incompetent'));
    end
end

% Plot: Competence for Drains (10/25-yr)
x = 1:4;
width = 0.35;
figure('Position', [100, 100, 800, 500]);
bar(x - width/2, double(competent_10yr_drains), width, 'FaceColor', [0.2 0.6 1]);
hold on;
bar(x + width/2, double(competent_25yr_drains), width, 'FaceColor', [1 0.4 0.2]);
xlabel('Drain Sections');
ylabel('Competence (1=Yes, 0=No)');
title('Hydraulic Competence Assessment for Drains (10 & 25-yr)');
set(gca, 'XTick', x, 'XTickLabel', sections(1:4), 'XTickLabelRotation', 45);
legend('10-yr Competent', '25-yr Competent', 'Location', 'best');
grid on;
saveas(gcf, 'competence_assessment.png');

% Plot: Competence for Culverts (25/50-yr)
x_c = 1:6;
figure('Position', [100, 100, 800, 500]);
bar(x_c - width/2, double(competent_25yr_culv), width, 'FaceColor', [0.2 0.6 1]);
hold on;
bar(x_c + width/2, double(competent_50yr_culv), width, 'FaceColor', [1 0.4 0.2]);
xlabel('Culvert Sections');
ylabel('Competence (1=Yes, 0=No)');
title('Hydraulic Competence Assessment for Culverts (25 & 50-yr)');
set(gca, 'XTick', x_c, 'XTickLabel', sections(5:10), 'XTickLabelRotation', 45);
legend('25-yr Competent', '50-yr Competent', 'Location', 'best');
grid on;
saveas(gcf, 'culvert_competence.png');

%% 5. Recommendations Plot (Qualitative Pie Chart)
recommendations = {'Sustainable Design Options', 'Silt Traps', 'Better Solid Waste Mgmt', 'Regular Maintenance'};
percent = [25, 25, 25, 25];  % Equal weights
figure('Position', [100, 100, 600, 600]);
pie(percent, recommendations);
title('Recommended Interventions for Drainage Improvement');
saveas(gcf, 'recommendations.png');

fprintf('\nPlots generated and saved:\n');
fprintf('1. rainfall_fit.png - Gumbel distribution fit\n');
fprintf('2. design_storms.png - Design rainfall vs return period\n');
fprintf('3. watershed_params.png - Watershed parameters distributions\n');
fprintf('4. runoff_hydrograph.png - Sample runoff hydrograph\n');
fprintf('5. competence_assessment.png - Drains competence\n');
fprintf('6. culvert_competence.png - Culverts competence\n');
fprintf('7. recommendations.png - Recommended interventions\n');

%% Helper function (if needed)
function str = ifelse(cond, true_str, false_str)
    if cond
        str = true_str;
    else
        str = false_str;
    end
end